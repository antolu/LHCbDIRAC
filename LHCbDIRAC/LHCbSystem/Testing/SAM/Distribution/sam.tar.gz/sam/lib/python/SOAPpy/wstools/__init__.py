#! /usr/bin/env python
"""WSDL parsing services package for Web Services for Python."""

ident = "$Id: __init__.py,v 1.1 2006/05/09 07:49:33 pnyczyk Exp $"

import WSDLTools
import XMLname

