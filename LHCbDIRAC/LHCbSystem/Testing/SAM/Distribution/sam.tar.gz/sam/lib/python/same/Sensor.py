import os
import sys
from same import Config
from same.Config import config
from same import Database
from same import Scheduler

same_home=os.environ['SAME_HOME']

def setupDir(dir):
    try:
	os.chdir(dir)
    except:
	os.makedirs(dir)
	os.chdir(dir)


def setupWorkDir():
    global same_work
    if os.environ.has_key('SAME_WORK'):
        same_work=os.environ['SAME_WORK']
    else:
        same_work=config.get('DEFAULT','workdir')
        os.environ['SAME_WORK']=same_work
    setupDir(same_work)

def setupSensorDir(sensor):
    sensordir=same_work+'/'+sensor
    setupDir(sensordir)
    

def setupTestsEnv():
    os.environ['SAME_VO']=config.get('submission','vo')
    for status in ['OK','INFO','NOTICE','WARNING','ERROR','CRITICAL','MAINTENANCE']:
	os.environ['SAME_'+status]=config.get('statuscode',status)
    
def setupSensorEnv(sensor):
    setupWorkDir()
    setupSensorDir(sensor)
    setupTestsEnv()
    os.environ['SAME_SENSOR_NAME']=sensor
    os.environ['SAME_SENSOR_HOME']=same_home+'/sensors/'+sensor
    os.environ['SAME_SENSOR_WORK']=same_work+'/'+sensor
    Config.save(same_work+'/'+sensor+'/same.conf')

def createFilter(sensor,user_filter):
    common_filter=config.get('sensors','common_filter').strip('"\'')
    try:
	sensor_filter=config.get('sensors','%s_filter'%sensor).strip('"\'')
    except:
	sensor_filter='serviceabbr=%s'%sensor
    filter_string=' '.join([common_filter,sensor_filter,user_filter])
    filter=dict(map(lambda x: (x[0],x[1].split(',')),map(lambda x: x.split('='),filter_string.split())))
    return filter

def getAttrs(sensor):
    try:
        attrs=config.get('sensors','%s_attrs'%sensor).strip('"\'')
    except:
        attrs=config.get('sensors','common_attrs').strip('"\'')
    return attrs.split();

def writeNodesFile(nodes,filename="nodes.map"):
    out=open(filename,"w")
    lines=map(lambda x: '\t'.join(x)+'\n',nodes)
    out.writelines(lines)
    out.close()

def executePrepareScript(sensor,args=''):
    cmd=same_home+'/sensors/'+sensor+'/prepare-'+sensor+' '+args

    p=os.popen(cmd,"r")
    lines=p.readlines()
    status=p.close()
    return status,lines

def executeCheckScripts(sensor,nodes,args=''):
    cmd=same_home+'/sensors/'+sensor+'/check-'+sensor+' '+args

    for node in nodes:
	Scheduler.run(cmd+' '+' '.join(node))

    Scheduler.wait()

def checkSensor(sensor):
    try:
        os.stat(same_home+'/sensors/'+sensor)
    except:
        return False
    return True

def operationExec(operation,sensor,user_filter,sensor_args):
    if operation == 'nodetest':
        return operationNodeTest(sensor,user_filter,sensor_args)
    
    if operation != 'submit':
        operationParam='--'+operation
    else:
        operationParam=''

    try:
        filter=createFilter(sensor,user_filter)
    except:
        print "Wrong filter format!"
        return
        
    attrs=getAttrs(sensor)
    sargs=' '.join(sensor_args)
    print "Sensor: "+sensor
    print "Node attrs: "+str(attrs)
    print "Node filter: "+str(filter)
    print "Sensor args: "+sargs

    try:
        nodes=Database.get(attrs,filter)
    except Exception,e:
        print "Query web service error!"
        print e.args[0]
        return
    
    print "\nMatching nodes: "+str(len(nodes))

    setupSensorEnv(sensor)
    writeNodesFile(nodes)

    print "Executing prepare script"
    print '-'*40
    status,lines=executePrepareScript(sensor,operationParam+" -i nodes.map "+sargs)
    print '-'*40
    if status:
	print "Prepare script failed! Giving up."
	sys.exit(status)

    if operation != 'submit':
        nodes=map(lambda x: tuple(x.split()),lines)
        
    print "Prepare script finished successfully"	
    print "Executing check script for all nodes"
    print '-'*40
    executeCheckScripts(sensor,nodes,operationParam)
    print '-'*40
    print "Executing check scripts finished"

def operationSubmit(sensor,user_filter,sensor_args):
    try:
        filter=createFilter(sensor,user_filter)
    except:
        print "Wrong filter format!"
        return
        
    attrs=getAttrs(sensor)
    sargs=' '.join(sensor_args)
    print "Sensor: "+sensor
    print "Node attrs: "+str(attrs)
    print "Node filter: "+str(filter)
    print "Sensor args: "+sargs

    try:
        nodes=Database.get(attrs,filter)
    except Exception,e:
        print "Query web service error!"
        print e.args[0]
        return
    
    print "\nMatching nodes: "+str(len(nodes))

    setupSensorEnv(sensor)
    writeNodesFile(nodes)

    print "Executing prepare script"
    print '-'*40
    status,lines=executePrepareScript(sensor,"-i nodes.map "+sargs)
    print '-'*40
    if status:
	print "Prepare script failed! Giving up."
	sys.exit(status)

    print "Prepare script finished successfully"	
    print "Executing check script for all nodes"
    print '-'*40
    executeCheckScripts(sensor,nodes)
    print '-'*40
    print "Executing check scripts finished"


def operationPublish(sensor,user_filter,sensor_args):
    print "Sensor: "+sensor

    setupSensorEnv(sensor)

    sargs="--publish "+' '.join(sensor_args)
    print "Executing prepare script"
    print '-'*40
    status,lines=executePrepareScript(sensor,sargs)
    print '-'*40
    if status:
	print "Prepare script failed! Giving up."
	sys.exit(status)
    nodes=map(lambda x: tuple(x.split()),lines)
    print "Prepare script finished successfully"
    if nodes:  
        print "Executing check script for all nodes"
        print '-'*40
        executeCheckScripts(sensor,nodes,"--publish ")
        print '-'*40
        print "Executing check scripts finished"

def operationStatus(sensor,user_filter,sensor_args):
    print "Sensor: "+sensor

    setupSensorEnv(sensor)

    sargs=' '.join(sensor_args)
    print "Executing prepare script"
    print '-'*40
    status,lines=executePrepareScript(sensor,"--status -i nodes.map "+sargs)
    print '-'*40
    if status:
	print "Prepare script failed! Giving up."
	sys.exit(status)
    nodes=map(lambda x: tuple(x.split()),lines)
    print "Prepare script finished successfully"	
    if nodes:  
        print "Executing check script for all nodes"
        print '-'*40
        executeCheckScripts(sensor,nodes,"--status ")
        print '-'*40
        print "Executing check scripts finished"

def operationCancel(sensor,nodes_list,sensor_args):
    print "Sensor: "+sensor

    nodes=map(lambda x: (x,), nodes_list.split())

    setupSensorEnv(sensor)
    writeNodesFile(nodes)

    sargs="--cancel "+' '.join(sensor_args)
    print "Executing prepare script"
    print '-'*40
    status,lines=executePrepareScript(sensor,sargs)
    print '-'*40
    if status:
	print "Prepare script failed! Giving up."
	sys.exit(status)
    print "Prepare script finished successfully"	
    nodes=map(lambda x: tuple(x.split()),lines)
    print "Executing check script for all nodes"
    print '-'*40
    executeCheckScripts(sensor,nodes,"--cancel ")
    print '-'*40
    print "Executing check scripts finished"



def operationNodeTest(sensor,nodeName,sensor_args):
    sargs=' '.join(sensor_args)
    print "Sensor: "+sensor
    print "Node name: "+nodeName
    print "Sensor args: "+sargs

    nodes=[(nodeName,)]

    setupSensorEnv(sensor)
    writeNodesFile(nodes)

    print "Executing prepare script"
    print '-'*40
    status,lines=executePrepareScript(sensor,"-i nodes.map "+sargs)
    print '-'*40
    if status:
	print "Prepare script failed! Giving up."
	sys.exit(status)

    print "Prepare script finished successfully"	
    print "Executing check script for all nodes"
    print '-'*40
    executeCheckScripts(sensor,nodes)
    print '-'*40
    print "Executing check scripts finished"

